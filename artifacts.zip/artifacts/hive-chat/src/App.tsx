import { type FormEvent, type ReactNode, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { ArrowRight, ArrowUp, DoorOpen, Hash, HeartHandshake, LoaderCircle, MessageCircle, Radio, RefreshCw, Send, ShieldCheck, Sparkles, Users, Wifi, WifiOff } from 'lucide-react';
import { getGetChatStatsQueryKey, getHealthCheckQueryKey, useCreateChatSession, useGetChatStats, useHealthCheck } from '@workspace/api-client-react';
import type { ChatSession } from '@workspace/api-client-react';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

type ChatMessage = { id: string; text: string; mine: boolean; nickname: string; time: string };
type SocketState = 'idle' | 'connecting' | 'waiting' | 'matched' | 'reconnecting' | 'error';

const starterMessages: ChatMessage[] = [];

function formatTime() {
  return new Intl.DateTimeFormat(undefined, { hour: 'numeric', minute: '2-digit' }).format(new Date());
}

function initials(value: string) {
  return value.trim().slice(0, 2).toUpperCase() || '??';
}

function Home() {
  const [nickname, setNickname] = useState('');
  const [session, setSession] = useState<ChatSession | null>(null);
  const [socketState, setSocketState] = useState<SocketState>('idle');
  const [messages, setMessages] = useState<ChatMessage[]>(starterMessages);
  const [draft, setDraft] = useState('');
  const [error, setError] = useState('');
  const [partnerName, setPartnerName] = useState('someone new');
  const [statsTick, setStatsTick] = useState(false);
  const socketRef = useRef<WebSocket | null>(null);
  const reconnectTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const intentionallyClosed = useRef(false);
  const sessionRef = useRef<ChatSession | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  const statsQuery = useGetChatStats({
    query: { queryKey: getGetChatStatsQueryKey(), refetchInterval: 12000 },
  });
  useHealthCheck({
    query: { queryKey: getHealthCheckQueryKey(), refetchInterval: 30000 },
  });
  const createSession = useCreateChatSession();
  const stats = statsQuery.data;

  const closeSocket = useCallback(() => {
    intentionallyClosed.current = true;
    if (reconnectTimer.current) clearTimeout(reconnectTimer.current);
    socketRef.current?.close();
    socketRef.current = null;
  }, []);

  const sendSocket = useCallback((payload: Record<string, unknown>) => {
    const socket = socketRef.current;
    if (socket?.readyState === WebSocket.OPEN) socket.send(JSON.stringify(payload));
  }, []);

  const openSocket = useCallback((activeSession: ChatSession) => {
    intentionallyClosed.current = false;
    setSocketState('connecting');
    setError('');
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const socket = new WebSocket(`${protocol}//${window.location.host}/ws`);
    socketRef.current = socket;
    socket.onopen = () => {
      setSocketState('waiting');
      sendSocket({ type: 'join', sessionId: activeSession.id, token: activeSession.token, nickname: activeSession.nickname });
    };
    socket.onmessage = (event) => {
      try {
        const incoming = JSON.parse(event.data) as Record<string, unknown>;
        const payload = incoming.payload && typeof incoming.payload === 'object' ? incoming.payload as Record<string, unknown> : {};
        const kind = String(incoming.type ?? incoming.event ?? incoming.status ?? payload.type ?? '').toLowerCase();
        const partner = incoming.partner && typeof incoming.partner === 'object' ? incoming.partner as Record<string, unknown> : {};
        const incomingNickname = String(incoming.nickname ?? incoming.partnerNickname ?? incoming.peerNickname ?? incoming.user ?? partner.nickname ?? payload.nickname ?? 'someone new');
        if (['match', 'matched', 'partner_joined', 'connected'].some((part) => kind.includes(part))) {
          setPartnerName(incomingNickname === 'undefined' ? 'someone new' : incomingNickname);
          setSocketState('matched');
          setMessages((current) => current.length ? current : [{ id: 'welcome', text: 'A new conversation is open. Say hi when it feels right.', mine: false, nickname: incomingNickname, time: formatTime() }]);
          return;
        }
        if (['leave', 'disconnect', 'ended', 'partner_left'].some((part) => kind.includes(part))) {
          setPartnerName('someone new');
          setSocketState('waiting');
          setMessages([]);
          return;
        }
        const text = String(incoming.text ?? incoming.message ?? incoming.content ?? payload.text ?? payload.message ?? '');
        if (text) {
          const mine = Boolean(incoming.mine) || String(incoming.sender ?? incoming.from ?? '').toLowerCase() === 'me';
          setMessages((current) => [...current, { id: `${Date.now()}-${current.length}`, text, mine, nickname: mine ? activeSession.nickname : incomingNickname, time: formatTime() }]);
        }
      } catch {
        if (typeof event.data === 'string' && event.data.trim()) {
          setMessages((current) => [...current, { id: `${Date.now()}`, text: event.data, mine: false, nickname: partnerName, time: formatTime() }]);
        }
      }
    };
    socket.onerror = () => {
      setError('The hive is having trouble connecting.');
      setSocketState('error');
    };
    socket.onclose = () => {
      socketRef.current = null;
      if (!intentionallyClosed.current && sessionRef.current) {
        setSocketState('reconnecting');
        reconnectTimer.current = setTimeout(() => openSocket(activeSession), 1800);
      }
    };
  }, [sendSocket]);

  useEffect(() => {
    sessionRef.current = session;
    if (session) openSocket(session);
    return () => closeSocket();
  }, [session, openSocket, closeSocket]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const startChat = (event: FormEvent) => {
    event.preventDefault();
    const cleanName = nickname.trim().slice(0, 24);
    if (!cleanName) {
      setError('Pick a nickname so your new conversation knows what to call you.');
      return;
    }
    setError('');
    setMessages([]);
    createSession.mutate({ data: { nickname: cleanName } }, {
      onSuccess: (created) => {
        setNickname(created.nickname);
        setSession(created);
      },
      onError: () => setError('Could not create your anonymous session. Try once more.'),
    });
  };

  const leaveRoom = (goNext = false) => {
    sendSocket({ type: goNext ? 'next' : 'leave' });
    closeSocket();
    setSession(null);
    setSocketState('idle');
    setMessages([]);
    setError('');
    if (goNext) setTimeout(() => document.getElementById('nickname-input')?.focus(), 50);
  };

  const submitMessage = (event: FormEvent) => {
    event.preventDefault();
    const text = draft.trim();
    if (!text || socketState !== 'matched') return;
    sendSocket({ type: 'message', message: text, text });
    setMessages((current) => [...current, { id: `${Date.now()}`, text, mine: true, nickname: session?.nickname ?? nickname, time: formatTime() }]);
    setDraft('');
  };

  const refreshStats = () => {
    setStatsTick(true);
    void statsQuery.refetch().finally(() => setTimeout(() => setStatsTick(false), 350));
  };

  const total = Math.max(stats?.total ?? 0, 1);
  const roomStatus = socketState === 'matched' ? 'Conversation live' : socketState === 'waiting' ? 'Looking for a person' : socketState === 'reconnecting' ? 'Reconnecting' : socketState === 'error' ? 'Connection issue' : 'Ready when you are';
  const statusClass = socketState === 'matched' ? 'online' : socketState === 'waiting' || socketState === 'connecting' || socketState === 'reconnecting' ? 'waiting' : socketState === 'error' ? 'error' : '';

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="/" data-testid="link-home">
          <span className="brand-mark"><Hash size={18} strokeWidth={3} /></span>
          <span>hive chat</span>
        </a>
        <div className="live-pill" data-testid="status-hive-live"><span className="live-dot" /> the hive is open</div>
      </header>
      <main className="main-grid">
        <section className="intro">
          <div className="eyebrow"><span className="eyebrow-line" /> one stranger. one moment.</div>
          <h1 className="headline">A tiny chat with<br /><em>someone new.</em></h1>
          <p className="subhead">No profiles to perform. No feed to scroll. Just a warm little corner of the internet and one person you haven't met yet.</p>
        </section>
        <section className="workspace">
          <div className="chat-card" data-testid="card-chat-room">
            <div className="chat-card-header">
              <div className="room-label">
                <div className="room-orb"><MessageCircle size={18} strokeWidth={2.4} /></div>
                <div>
                  <div className="room-name">{socketState === 'matched' ? `with ${partnerName}` : 'the waiting room'}</div>
                  <div className="room-status"><span className={`status-dot ${statusClass}`} /> <span data-testid="status-connection">{roomStatus}</span></div>
                </div>
              </div>
              <div className="header-actions">
                <button className="icon-btn" type="button" aria-label="Refresh room stats" onClick={refreshStats} data-testid="button-refresh-stats"><RefreshCw className={statsTick ? 'refreshing' : ''} size={16} /></button>
                {session && socketState === 'matched' && <button className="icon-btn" type="button" aria-label="Meet someone else" onClick={() => leaveRoom(true)} data-testid="button-next-person"><ArrowRight size={16} /></button>}
                {session && <button className="icon-btn danger" type="button" aria-label="Leave conversation" onClick={() => leaveRoom()} data-testid="button-disconnect"><DoorOpen size={16} /></button>}
              </div>
            </div>
            <div className="chat-body">
              {socketState === 'idle' && !createSession.isPending && (
                <div className="welcome-state">
                  <div className="hive-symbol"><Sparkles size={34} /></div>
                  <h2>Step into the hive.</h2>
                  <p>Choose a nickname, then we'll find a curious stranger who's ready for a real conversation.</p>
                  <form className="name-form" onSubmit={startChat}>
                    <input id="nickname-input" data-testid="input-nickname" value={nickname} onChange={(event) => { setNickname(event.target.value); setError(''); }} maxLength={24} placeholder="a name for this moment" autoComplete="off" />
                    <button className="primary-btn" type="submit" disabled={!nickname.trim()} data-testid="button-start-chat">Enter <ArrowUp size={15} /></button>
                  </form>
                  {error && <p className="error-copy" data-testid="text-start-error">{error}</p>}
                </div>
              )}
              {createSession.isPending && (
                <div className="waiting-state">
                  <div className="waiting-ring"><LoaderCircle size={31} className="animate-spin" /></div>
                  <h2>Getting your wings ready.</h2>
                  <p>Making a private, anonymous session for you.</p>
                  <div className="waiting-progress"><i /></div>
                </div>
              )}
              {session && ['connecting', 'waiting', 'reconnecting'].includes(socketState) && !createSession.isPending && (
                <div className="waiting-state">
                  <div className="waiting-ring"><Radio size={31} /></div>
                  <h2>{socketState === 'reconnecting' ? 'Finding the signal.' : 'Listening for a buzz.'}</h2>
                  <p>{socketState === 'reconnecting' ? 'Your connection took a tiny detour. We are trying again.' : 'We’ll pair you with one person. The best conversations often start simply.'}</p>
                  <div className="waiting-progress"><i /></div>
                  <div className="waiting-note"><Wifi size={13} /> anonymous connection in progress</div>
                  <button className="cancel-btn" type="button" onClick={() => leaveRoom()} data-testid="button-cancel-waiting">Leave the waiting room</button>
                </div>
              )}
              {session && socketState === 'error' && (
                <div className="offline-state">
                  <div className="hive-symbol"><WifiOff size={32} /></div>
                  <h2>That buzz got lost.</h2>
                  <p>{error || 'We could not reach the hive right now. Your nickname is safe to try again.'}</p>
                  <button className="primary-btn" type="button" onClick={() => session && openSocket(session)} data-testid="button-reconnect">Try connecting <RefreshCw size={15} /></button>
                </div>
              )}
              {session && socketState === 'matched' && (
                <div className="messages" data-testid="list-messages">
                  {messages.length === 0 && <div className="waiting-note" style={{ alignSelf: 'center', margin: 'auto' }}><HeartHandshake size={14} /> Your conversation starts here.</div>}
                  {messages.map((message) => (
                    <div className={`message-row ${message.mine ? 'mine' : ''}`} key={message.id} data-testid={`message-${message.id}`}>
                      <div className={`avatar ${message.mine ? 'mine' : ''}`}>{initials(message.nickname)}</div>
                      <div><div className="bubble">{message.text}</div><div className="message-meta">{message.mine ? 'you' : message.nickname} · {message.time}</div></div>
                    </div>
                  ))}
                  <div ref={bottomRef} />
                </div>
              )}
            </div>
            {session && socketState === 'matched' && (
              <form className="composer" onSubmit={submitMessage}>
                <input data-testid="input-message" value={draft} onChange={(event) => setDraft(event.target.value)} placeholder="say something small..." autoComplete="off" maxLength={1000} />
                <button className="send-btn" type="submit" disabled={!draft.trim()} aria-label="Send message" data-testid="button-send-message"><Send size={16} /></button>
              </form>
            )}
          </div>
          <aside className="side-stack">
            <div className="stat-card" data-testid="card-room-stats">
              <div className="side-title"><span>hive pulse</span><span className="mono">live</span></div>
              {statsQuery.isLoading ? <><div className="skeleton" style={{ height: 46, width: 100, borderRadius: 8 }} /><div className="skeleton" style={{ height: 50, marginTop: 14, borderRadius: 7 }} /></> : statsQuery.isError ? <div className="waiting-note"><WifiOff size={13} /> pulse unavailable</div> : <>
                <div className="stat-big"><span className="stat-number" data-testid="text-total-count">{stats?.total ?? 0}</span><span className="stat-caption">in the hive</span></div>
                <div className="stat-bars">
                  <div className="stat-bar-line"><span>waiting</span><div className="bar"><i style={{ width: `${Math.min(((stats?.waiting ?? 0) / total) * 100, 100)}%` }} /></div><b>{stats?.waiting ?? 0}</b></div>
                  <div className="stat-bar-line"><span>talking</span><div className="bar chatting"><i style={{ width: `${Math.min(((stats?.chatting ?? 0) / total) * 100, 100)}%` }} /></div><b>{stats?.chatting ?? 0}</b></div>
                </div>
              </>}
            </div>
            <div className="safety-card" data-testid="card-safety">
              <div className="safety-icon"><ShieldCheck size={17} /></div>
              <h3>Keep it kind.</h3>
              <p>You are anonymous, but there is a real person on the other side. A quick exit is always okay.</p>
              <div className="safety-rule"><HeartHandshake size={14} /> No pressure. No personal details. Trust your read of the room.</div>
            </div>
          </aside>
        </section>
      </main>
      <footer className="footer-note"><span>built for the pleasantly unexpected</span><span className="mono"><Users size={12} style={{ verticalAlign: 'middle', marginRight: 5 }} />{stats?.chatting ?? '—'} conversations right now</span></footer>
    </div>
  );
}

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
