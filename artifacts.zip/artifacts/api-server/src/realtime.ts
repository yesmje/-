import { randomUUID } from "node:crypto";
import type { Server as HttpServer } from "node:http";
import { WebSocket, WebSocketServer } from "ws";
import { logger } from "./lib/logger";

type Session = {
  id: string;
  nickname: string;
  token: string;
};

type Client = {
  socket: WebSocket;
  session: Session;
  partner?: Client;
  matched: boolean;
};

type ClientMessage =
  | {
      type: "join";
      session?: Session;
      sessionId?: string;
      token?: string;
      nickname?: string;
    }
  | { type: "message"; text: string }
  | { type: "leave" };

const waiting: Client[] = [];
const clients = new Set<Client>();

function send(client: Client, payload: unknown) {
  if (client.socket.readyState === WebSocket.OPEN) {
    client.socket.send(JSON.stringify(payload));
  }
}

function stats() {
  const chatting = [...clients].filter((client) => client.matched).length;
  return {
    waiting: waiting.length,
    chatting: Math.floor(chatting / 2),
    total: clients.size,
  };
}

function announceStats() {
  const payload = { type: "stats", stats: stats() };
  for (const client of clients) send(client, payload);
}

function removeFromQueue(client: Client) {
  const index = waiting.indexOf(client);
  if (index >= 0) waiting.splice(index, 1);
}

function disconnect(client: Client, notifyPartner = true) {
  removeFromQueue(client);
  clients.delete(client);

  if (client.partner) {
    const partner = client.partner;
    client.partner = undefined;
    partner.partner = undefined;
    partner.matched = false;
    if (notifyPartner) {
      send(partner, {
        type: "partner_left",
        message: "상대방이 대화를 종료했어요.",
      });
    }
  }

  announceStats();
}

function matchmake() {
  while (waiting.length >= 2) {
    const first = waiting.shift();
    const second = waiting.shift();
    if (!first || !second) return;

    first.partner = second;
    second.partner = first;
    first.matched = true;
    second.matched = true;
    const conversationId = randomUUID();

    send(first, {
      type: "matched",
      conversationId,
      peer: { nickname: second.session.nickname },
    });
    send(second, {
      type: "matched",
      conversationId,
      peer: { nickname: first.session.nickname },
    });
  }
  announceStats();
}

function parseMessage(raw: string): ClientMessage | undefined {
  try {
    const value = JSON.parse(raw) as ClientMessage;
    if (!value || typeof value !== "object" || typeof value.type !== "string") {
      return undefined;
    }
    return value;
  } catch {
    return undefined;
  }
}

export function getChatStats() {
  return stats();
}

export function attachRealtime(server: HttpServer) {
  const websocketServer = new WebSocketServer({ noServer: true });

  server.on("upgrade", (request, socket, head) => {
    const url = new URL(request.url ?? "/", "http://localhost");
    if (url.pathname !== "/ws") {
      socket.destroy();
      return;
    }

    websocketServer.handleUpgrade(request, socket, head, (websocket) => {
      websocketServer.emit("connection", websocket, request);
    });
  });

  websocketServer.on("connection", (socket) => {
    let client: Client | undefined;

    socket.on("message", (raw) => {
      const message = parseMessage(raw.toString());
      if (!message) {
        send(client ?? { socket, session: {} as Session, matched: false }, {
          type: "error",
          message: "잘못된 요청이에요.",
        });
        return;
      }

      if (message.type === "join") {
        const incomingSession = message.session ?? {
          id: message.sessionId,
          token: message.token,
          nickname: message.nickname,
        };
        if (
          client ||
          !incomingSession.id ||
          !incomingSession.token ||
          !incomingSession.nickname
        ) {
          send(client ?? { socket, session: {} as Session, matched: false }, {
            type: "error",
            message: "채팅방에 이미 참여했어요.",
          });
          return;
        }

        client = {
          socket,
          session: {
            id: incomingSession.id,
            token: incomingSession.token,
            nickname: incomingSession.nickname,
          },
          matched: false,
        };
        clients.add(client);
        waiting.push(client);
        send(client, { type: "waiting", stats: stats() });
        matchmake();
        return;
      }

      if (!client) {
        send({ socket, session: {} as Session, matched: false }, {
          type: "error",
          message: "먼저 채팅에 입장해 주세요.",
        });
        return;
      }

      if (message.type === "message") {
        const text = message.text.trim().slice(0, 1000);
        if (!text || !client.partner) return;
        send(client.partner, {
          type: "message",
          id: randomUUID(),
          text,
          createdAt: new Date().toISOString(),
        });
        return;
      }

      if (message.type === "leave") {
        disconnect(client);
        client = undefined;
        return;
      }
    });

    socket.on("close", () => {
      if (client) disconnect(client);
    });

    socket.on("error", (error) => {
      logger.warn({ error }, "WebSocket client error");
    });
  });

  logger.info("Realtime chat WebSocket server attached");
}