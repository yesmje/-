import { Router, type IRouter } from "express";
import {
  CreateChatSessionBody,
  CreateChatSessionResponse,
  GetChatStatsResponse,
} from "@workspace/api-zod";
import { randomUUID } from "node:crypto";
import { getChatStats } from "../realtime";

const router: IRouter = Router();

router.get("/chat/stats", (req, res) => {
  const data = GetChatStatsResponse.parse(getChatStats());
  req.log.info({ stats: data }, "Chat stats requested");
  res.json(data);
});

router.post("/chat/session", (req, res) => {
  const body = CreateChatSessionBody.parse(req.body);
  const data = CreateChatSessionResponse.parse({
    id: randomUUID(),
    nickname: body.nickname.trim(),
    token: randomUUID(),
  });
  req.log.info({ sessionId: data.id }, "Anonymous chat session created");
  res.status(201).json(data);
});

export default router;